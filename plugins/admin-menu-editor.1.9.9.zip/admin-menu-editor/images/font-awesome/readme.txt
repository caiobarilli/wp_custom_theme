This directory contains icons from the Font Awesome 4.4.0 icon font:
http://fortawesome.github.io/Font-Awesome/

The Font Awesome font is licensed under SIL OFL 1.1:
http://scripts.sil.org/OFL

------------------------------------------------------------------------------

The icons have been converted to PNG and in some cases minor adjustments have 
been made, such as adding a background colour or a drop shadow. 