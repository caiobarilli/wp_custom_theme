<h2>
    Loco Translate home screen
</h2>
<p>
    From the home screen you can access recently used items and your active theme.
    To translate other themes, plugins, or the WordPress core, use the subsection links in the side menu.
</p>